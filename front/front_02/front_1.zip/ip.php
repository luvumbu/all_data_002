<div id="ip" title="<?php echo $_SERVER['REMOTE_ADDR'] ;?>"></div>

