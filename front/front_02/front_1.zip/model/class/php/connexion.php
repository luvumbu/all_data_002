<?php

$dbname="u489596434_ffa";
$username="u489596434_ffa";
$password="v3p9r3e@59A";
$servername="localhost";

?>
