<?php 
include("section.html");
include("model1.html");
?>



 
 
 